/* StayEase - Hotel Management frontend (vanilla JS) */
const $ = (s) => document.querySelector(s);
let token = localStorage.getItem('hms_token');

// ---------- Helpers ----------
const esc = (v) =>
  String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = (n) => '₹' + Number(n || 0).toLocaleString('en-IN');
const todayStr = () => new Date().toLocaleDateString('en-CA');
const label = (s) => ({ checked_in: 'Checked in', checked_out: 'Checked out' }[s] || s.charAt(0).toUpperCase() + s.slice(1));
const fmtDate = (d) => new Date(d + 'T00:00:00').toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });

async function api(url, method = 'GET', body) {
  const res = await fetch('/api' + url, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && url !== '/login') {
    logout();
    throw new Error('Session expired. Please login again.');
  }
  if (!res.ok) throw new Error(data.error || 'Something went wrong');
  return data;
}

let toastTimer;
function toast(msg, isError = false) {
  const t = $('#toast');
  t.textContent = msg;
  t.className = 'toast' + (isError ? ' error' : '');
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.hidden = true), 3000);
}

// ---------- Modal ----------
function openModal(title, html, onSubmit) {
  $('#modalTitle').textContent = title;
  const form = $('#modalForm');
  form.innerHTML = html;
  $('#modal').hidden = false;
  form.onsubmit = async (e) => {
    e.preventDefault();
    const old = form.querySelector('.form-error');
    if (old) old.remove();
    try {
      await onSubmit(Object.fromEntries(new FormData(form)), form);
      closeModal();
    } catch (err) {
      const box = document.createElement('div');
      box.className = 'form-error';
      box.textContent = err.message;
      form.prepend(box);
    }
  };
  const first = form.querySelector('input, select');
  if (first) first.focus();
}
function closeModal() {
  $('#modal').hidden = true;
  $('#modalForm').innerHTML = '';
}
$('#modalClose').onclick = closeModal;
$('#modal').addEventListener('click', (e) => { if (e.target.id === 'modal') closeModal(); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });

const formButtons = (okText) =>
  `<div class="form-actions"><button type="button" class="btn ghost" onclick="closeModal()">Cancel</button><button class="btn primary">${okText}</button></div>`;

// ---------- Auth ----------
function showApp() {
  $('#login').hidden = true;
  $('#app').hidden = false;
  route();
}
function logout() {
  token = null;
  localStorage.removeItem('hms_token');
  $('#app').hidden = true;
  $('#login').hidden = false;
}
$('#logout').onclick = logout;

$('#loginForm').onsubmit = async (e) => {
  e.preventDefault();
  const f = Object.fromEntries(new FormData(e.target));
  try {
    const r = await api('/login', 'POST', f);
    token = r.token;
    localStorage.setItem('hms_token', token);
    showApp();
  } catch (err) {
    toast(err.message, true);
  }
};

// ---------- Router ----------
const views = {
  dashboard: { title: 'Dashboard', render: renderDashboard },
  bookings: { title: 'Bookings', render: renderBookings },
  rooms: { title: 'Rooms', render: renderRooms },
  guests: { title: 'Guests', render: renderGuests },
};

async function route() {
  if (!token) return;
  const name = (location.hash || '#dashboard').slice(1);
  const v = views[name] || views.dashboard;
  document.querySelectorAll('#nav a').forEach((a) => a.classList.toggle('active', a.dataset.view === (views[name] ? name : 'dashboard')));
  $('#pageTitle').textContent = v.title;
  $('#pageDate').textContent = new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  $('#pageActions').innerHTML = '';
  $('#view').innerHTML = '<p class="muted">Loading...</p>';
  try {
    await v.render();
  } catch (err) {
    if (token) $('#view').innerHTML = `<div class="empty">${esc(err.message)}</div>`;
  }
}
window.addEventListener('hashchange', route);

// ---------- Dashboard ----------
async function renderDashboard() {
  const d = await api('/dashboard');
  const stat = (ico, color, num, lbl) =>
    `<div class="card stat"><div class="ico ${color}">${ico}</div><div><div class="num">${num}</div><div class="lbl">${lbl}</div></div></div>`;
  const rows = d.recent
    .map(
      (b) => `<tr>
        <td><b>${esc(b.guest_name)}</b></td>
        <td>Room ${esc(b.room_number)} <span class="sub">· ${esc(b.room_type)}</span></td>
        <td>${fmtDate(b.check_in)} → ${fmtDate(b.check_out)}</td>
        <td>${money(b.total)}</td>
        <td><span class="badge ${b.status}">${label(b.status)}</span></td>
      </tr>`
    )
    .join('');
  $('#view').innerHTML = `
    <div class="stats">
      ${stat('🛏️', 'indigo', d.totalRooms, 'Total rooms')}
      ${stat('✅', 'green', d.available, 'Available rooms')}
      ${stat('🔑', 'blue', d.occupied, 'Occupied rooms')}
      ${stat('🛠️', 'amber', d.maintenance, 'Under maintenance')}
    </div>
    <div class="stats">
      ${stat('🧳', 'indigo', d.checkinsToday, 'Check-ins today')}
      ${stat('🚪', 'amber', d.checkoutsToday, 'Check-outs today')}
      ${stat('👥', 'blue', d.totalGuests, 'Total guests')}
      ${stat('💰', 'green', money(d.revenue), 'Revenue')}
    </div>
    <div class="card">
      <h3 style="margin-bottom:12px">Recent bookings</h3>
      ${
        rows
          ? `<div class="table-wrap"><table><thead><tr><th>Guest</th><th>Room</th><th>Stay</th><th>Total</th><th>Status</th></tr></thead><tbody>${rows}</tbody></table></div>`
          : '<div class="empty">No bookings yet</div>'
      }
    </div>`;
}

// ---------- Rooms ----------
let roomFilter = 'all';

async function renderRooms() {
  $('#pageActions').innerHTML = '<button class="btn primary" id="addRoom">+ Add room</button>';
  $('#addRoom').onclick = () => roomForm();
  const rooms = await api('/rooms');
  const list = roomFilter === 'all' ? rooms : rooms.filter((r) => r.status === roomFilter);
  const chip = (k, t) => `<button class="chip ${roomFilter === k ? 'active' : ''}" data-f="${k}">${t}</button>`;

  $('#view').innerHTML = `
    <div class="chips">
      ${chip('all', `All (${rooms.length})`)}
      ${chip('available', 'Available')}
      ${chip('occupied', 'Occupied')}
      ${chip('maintenance', 'Maintenance')}
    </div>
    ${
      list.length
        ? `<div class="rooms">${list
            .map(
              (r) => `<div class="card room">
              <div class="row"><span class="rn">${esc(r.number)}</span><span class="badge ${r.status}">${label(r.status)}</span></div>
              <div>${esc(r.type)} <span class="muted">· up to ${r.capacity} guests</span></div>
              <div class="price">${money(r.price)} <span class="muted">/ night</span></div>
              <div class="actions">
                <button class="btn ghost sm" data-edit="${r.id}">Edit</button>
                <button class="btn danger sm" data-del="${r.id}">Delete</button>
              </div>
            </div>`
            )
            .join('')}</div>`
        : '<div class="empty">No rooms found</div>'
    }`;

  document.querySelectorAll('[data-f]').forEach((b) => (b.onclick = () => { roomFilter = b.dataset.f; renderRooms(); }));
  document.querySelectorAll('[data-edit]').forEach((b) => (b.onclick = () => roomForm(rooms.find((r) => r.id == b.dataset.edit))));
  document.querySelectorAll('[data-del]').forEach((b) => (b.onclick = async () => {
    if (!confirm('Delete this room?')) return;
    try { await api('/rooms/' + b.dataset.del, 'DELETE'); toast('Room deleted'); renderRooms(); }
    catch (err) { toast(err.message, true); }
  }));
}

function roomForm(room) {
  const r = room || { number: '', type: 'Standard', price: '', capacity: 2, status: 'available' };
  const opt = (list, val) => list.map((o) => `<option value="${o}" ${o === val ? 'selected' : ''}>${o}</option>`).join('');
  openModal(room ? 'Edit room' : 'Add room', `
    <div class="grid2">
      <label>Room number<input name="number" value="${esc(r.number)}" required /></label>
      <label>Type<select name="type">${opt(['Standard', 'Deluxe', 'Suite', 'Presidential'], r.type)}</select></label>
      <label>Price / night (₹)<input name="price" type="number" min="1" value="${esc(r.price)}" required /></label>
      <label>Capacity<input name="capacity" type="number" min="1" max="10" value="${esc(r.capacity)}" required /></label>
    </div>
    ${room ? `<label>Status<select name="status">${opt(['available', 'occupied', 'maintenance'], r.status)}</select></label>` : ''}
    ${formButtons(room ? 'Save changes' : 'Add room')}`,
    async (f) => {
      if (room) await api('/rooms/' + room.id, 'PUT', f);
      else await api('/rooms', 'POST', f);
      toast(room ? 'Room updated' : 'Room added');
      renderRooms();
    });
}

// ---------- Guests ----------
let guestQuery = '';

async function renderGuests() {
  $('#pageActions').innerHTML = `
    <input class="search" id="guestSearch" placeholder="Search name, phone, email" value="${esc(guestQuery)}" />
    <button class="btn primary" id="addGuest">+ Add guest</button>`;
  $('#addGuest').onclick = () => guestForm();
  let timer;
  $('#guestSearch').oninput = (e) => {
    guestQuery = e.target.value;
    clearTimeout(timer);
    timer = setTimeout(() => loadGuests(), 250);
  };
  $('#view').innerHTML = '<div class="card"><div id="guestTable"></div></div>';
  await loadGuests();
}

async function loadGuests() {
  const guests = await api('/guests?q=' + encodeURIComponent(guestQuery));
  const box = $('#guestTable');
  if (!box) return;
  if (!guests.length) { box.innerHTML = '<div class="empty">No guests found</div>'; return; }
  box.innerHTML = `<div class="table-wrap"><table>
    <thead><tr><th>Name</th><th>Contact</th><th>ID proof</th><th>Stays</th><th></th></tr></thead>
    <tbody>${guests.map((g) => `<tr>
      <td><b>${esc(g.name)}</b></td>
      <td>${esc(g.phone) || '-'}<div class="sub">${esc(g.email)}</div></td>
      <td>${esc(g.id_proof) || '-'}</td>
      <td>${g.stays}</td>
      <td><div class="actions">
        <button class="btn ghost sm" data-edit="${g.id}">Edit</button>
        <button class="btn danger sm" data-del="${g.id}">Delete</button>
      </div></td></tr>`).join('')}</tbody></table></div>`;
  box.querySelectorAll('[data-edit]').forEach((b) => (b.onclick = () => guestForm(guests.find((g) => g.id == b.dataset.edit))));
  box.querySelectorAll('[data-del]').forEach((b) => (b.onclick = async () => {
    if (!confirm('Delete this guest?')) return;
    try { await api('/guests/' + b.dataset.del, 'DELETE'); toast('Guest deleted'); loadGuests(); }
    catch (err) { toast(err.message, true); }
  }));
}

function guestForm(guest) {
  const g = guest || { name: '', phone: '', email: '', id_proof: '' };
  openModal(guest ? 'Edit guest' : 'Add guest', `
    <label>Full name<input name="name" value="${esc(g.name)}" required /></label>
    <div class="grid2">
      <label>Phone<input name="phone" value="${esc(g.phone)}" /></label>
      <label>Email<input name="email" type="email" value="${esc(g.email)}" /></label>
    </div>
    <label>ID proof<input name="id_proof" placeholder="e.g. Aadhaar - 1234 5678 9012" value="${esc(g.id_proof)}" /></label>
    ${formButtons(guest ? 'Save changes' : 'Add guest')}`,
    async (f) => {
      if (guest) await api('/guests/' + guest.id, 'PUT', f);
      else await api('/guests', 'POST', f);
      toast(guest ? 'Guest updated' : 'Guest added');
      if (location.hash === '#guests') loadGuests();
    });
}

// ---------- Bookings ----------
let bookingFilter = 'all';

async function renderBookings() {
  $('#pageActions').innerHTML = '<button class="btn primary" id="addBooking">+ New booking</button>';
  $('#addBooking').onclick = bookingForm;
  const all = await api('/bookings');
  const list = bookingFilter === 'all' ? all : all.filter((b) => b.status === bookingFilter);
  const chip = (k, t) => `<button class="chip ${bookingFilter === k ? 'active' : ''}" data-f="${k}">${t}</button>`;

  const actions = (b) => {
    if (b.status === 'booked')
      return `<button class="btn success sm" data-act="checkin" data-id="${b.id}">Check-in</button>
              <button class="btn danger sm" data-act="cancel" data-id="${b.id}">Cancel</button>`;
    if (b.status === 'checked_in')
      return `<button class="btn warn sm" data-act="checkout" data-id="${b.id}">Check-out</button>`;
    return '';
  };

  $('#view').innerHTML = `
    <div class="chips">
      ${chip('all', `All (${all.length})`)}
      ${chip('booked', 'Booked')}
      ${chip('checked_in', 'Checked in')}
      ${chip('checked_out', 'Checked out')}
      ${chip('cancelled', 'Cancelled')}
    </div>
    <div class="card">
      ${
        list.length
          ? `<div class="table-wrap"><table>
            <thead><tr><th>#</th><th>Guest</th><th>Room</th><th>Stay</th><th>Total</th><th>Status</th><th></th></tr></thead>
            <tbody>${list.map((b) => `<tr>
              <td>${b.id}</td>
              <td><b>${esc(b.guest_name)}</b><div class="sub">${esc(b.guest_phone)}</div></td>
              <td>Room ${esc(b.room_number)}<div class="sub">${esc(b.room_type)} · ${b.guests_count} guest(s)</div></td>
              <td>${fmtDate(b.check_in)}<div class="sub">to ${fmtDate(b.check_out)}</div></td>
              <td>${money(b.total)}</td>
              <td><span class="badge ${b.status}">${label(b.status)}</span></td>
              <td><div class="actions">${actions(b)}</div></td></tr>`).join('')}</tbody></table></div>`
          : '<div class="empty">No bookings found</div>'
      }
    </div>`;

  document.querySelectorAll('[data-f]').forEach((b) => (b.onclick = () => { bookingFilter = b.dataset.f; renderBookings(); }));
  document.querySelectorAll('[data-act]').forEach((b) => (b.onclick = async () => {
    const { act, id } = b.dataset;
    if (act === 'cancel' && !confirm('Cancel this booking?')) return;
    try {
      await api(`/bookings/${id}/${act}`, 'PUT');
      toast({ checkin: 'Guest checked in', checkout: 'Guest checked out', cancel: 'Booking cancelled' }[act]);
      renderBookings();
    } catch (err) { toast(err.message, true); }
  }));
}

async function bookingForm() {
  const [guests, rooms] = await Promise.all([api('/guests'), api('/rooms')]);
  if (!guests.length) return toast('Add a guest first', true);
  const usable = rooms.filter((r) => r.status !== 'maintenance');
  if (!usable.length) return toast('No rooms available for booking', true);

  const tomorrow = new Date(); tomorrow.setDate(tomorrow.getDate() + 1);
  const t = todayStr(), tm = tomorrow.toLocaleDateString('en-CA');

  openModal('New booking', `
    <label>Guest<select name="guest_id">${guests.map((g) => `<option value="${g.id}">${esc(g.name)} (${esc(g.phone) || 'no phone'})</option>`).join('')}</select></label>
    <label>Room<select name="room_id">${usable.map((r) => `<option value="${r.id}" data-price="${r.price}">Room ${esc(r.number)} · ${esc(r.type)} · ${money(r.price)}/night</option>`).join('')}</select></label>
    <div class="grid2">
      <label>Check-in<input name="check_in" type="date" min="${t}" value="${t}" required /></label>
      <label>Check-out<input name="check_out" type="date" min="${tm}" value="${tm}" required /></label>
    </div>
    <label>Number of guests<input name="guests_count" type="number" min="1" max="10" value="1" required /></label>
    <div class="total-box" id="totalBox"></div>
    ${formButtons('Confirm booking')}`,
    async (f) => {
      await api('/bookings', 'POST', f);
      toast('Booking confirmed');
      if (location.hash === '#bookings') renderBookings();
      else location.hash = '#bookings';
    });

  const form = $('#modalForm');
  const calc = () => {
    const price = Number(form.room_id.selectedOptions[0].dataset.price);
    const nights = Math.round((new Date(form.check_out.value) - new Date(form.check_in.value)) / 86400000);
    $('#totalBox').textContent = nights >= 1 ? `${nights} night(s) × ${money(price)} = ${money(nights * price)}` : 'Check-out must be after check-in';
  };
  form.addEventListener('change', calc);
  calc();
}

// ---------- Start ----------
if (token) showApp();
