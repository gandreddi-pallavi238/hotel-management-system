const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, 'hotel.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS rooms (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  number TEXT UNIQUE NOT NULL,
  type TEXT NOT NULL,
  price REAL NOT NULL,
  capacity INTEGER NOT NULL DEFAULT 2,
  status TEXT NOT NULL DEFAULT 'available'   -- available | occupied | maintenance
);

CREATE TABLE IF NOT EXISTS guests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT,
  email TEXT,
  id_proof TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS bookings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guest_id INTEGER NOT NULL REFERENCES guests(id),
  room_id INTEGER NOT NULL REFERENCES rooms(id),
  check_in TEXT NOT NULL,
  check_out TEXT NOT NULL,
  guests_count INTEGER NOT NULL DEFAULT 1,
  total REAL NOT NULL,
  status TEXT NOT NULL DEFAULT 'booked',     -- booked | checked_in | checked_out | cancelled
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

// ---- Seed demo data on first run ----
const roomCount = db.prepare('SELECT COUNT(*) c FROM rooms').get().c;
if (roomCount === 0) {
  const addRoom = db.prepare('INSERT INTO rooms (number, type, price, capacity) VALUES (?, ?, ?, ?)');
  [
    ['101', 'Standard', 1500, 2],
    ['102', 'Standard', 1500, 2],
    ['103', 'Standard', 1600, 3],
    ['201', 'Deluxe', 2500, 2],
    ['202', 'Deluxe', 2500, 3],
    ['203', 'Deluxe', 2700, 3],
    ['301', 'Suite', 4500, 4],
    ['302', 'Suite', 4800, 4],
    ['401', 'Presidential', 8500, 5],
  ].forEach((r) => addRoom.run(...r));

  const addGuest = db.prepare('INSERT INTO guests (name, phone, email, id_proof) VALUES (?, ?, ?, ?)');
  addGuest.run('Ravi Kumar', '9876543210', 'ravi@example.com', 'Aadhaar - 1234 5678 9012');
  addGuest.run('Sneha Reddy', '9123456780', 'sneha@example.com', 'Driving License - AP09 2021');
  addGuest.run('Arjun Varma', '9988776655', 'arjun@example.com', 'Passport - K1234567');

  const fmt = (d) => d.toLocaleDateString('en-CA');
  const day = (n) => { const d = new Date(); d.setDate(d.getDate() + n); return fmt(d); };
  const addBooking = db.prepare(
    'INSERT INTO bookings (guest_id, room_id, check_in, check_out, guests_count, total, status) VALUES (?, ?, ?, ?, ?, ?, ?)'
  );
  addBooking.run(1, 1, day(-1), day(2), 2, 1500 * 3, 'checked_in');
  db.prepare("UPDATE rooms SET status='occupied' WHERE id=1").run();
  addBooking.run(2, 4, day(1), day(3), 2, 2500 * 2, 'booked');
  addBooking.run(3, 7, day(-5), day(-2), 3, 4500 * 3, 'checked_out');
}

module.exports = db;
