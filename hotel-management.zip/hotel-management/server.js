const express = require('express');
const crypto = require('crypto');
const path = require('path');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;

// Demo admin credentials (change these for real use)
const ADMIN_USER = 'admin';
const ADMIN_PASS = 'admin123';

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ---------- Auth ----------
const tokens = new Set();

app.post('/api/login', (req, res) => {
  const { username, password } = req.body || {};
  if (username === ADMIN_USER && password === ADMIN_PASS) {
    const token = crypto.randomBytes(24).toString('hex');
    tokens.add(token);
    return res.json({ token });
  }
  res.status(401).json({ error: 'Invalid username or password' });
});

app.use('/api', (req, res, next) => {
  const token = (req.headers.authorization || '').replace('Bearer ', '');
  if (!tokens.has(token)) return res.status(401).json({ error: 'Unauthorized' });
  next();
});

// ---------- Helpers ----------
const today = () => new Date().toLocaleDateString('en-CA'); // YYYY-MM-DD (local)
const one = (sql, ...p) => db.prepare(sql).get(...p);
const all = (sql, ...p) => db.prepare(sql).all(...p);
const bad = (res, msg, code = 400) => res.status(code).json({ error: msg });
const nightsBetween = (a, b) => Math.round((new Date(b) - new Date(a)) / 86400000);

const BOOKING_SELECT = `
  SELECT b.*, g.name AS guest_name, g.phone AS guest_phone,
         r.number AS room_number, r.type AS room_type
  FROM bookings b
  JOIN guests g ON g.id = b.guest_id
  JOIN rooms r ON r.id = b.room_id
`;

// ---------- Dashboard ----------
app.get('/api/dashboard', (req, res) => {
  const t = today();
  res.json({
    totalRooms: one('SELECT COUNT(*) c FROM rooms').c,
    available: one("SELECT COUNT(*) c FROM rooms WHERE status='available'").c,
    occupied: one("SELECT COUNT(*) c FROM rooms WHERE status='occupied'").c,
    maintenance: one("SELECT COUNT(*) c FROM rooms WHERE status='maintenance'").c,
    totalGuests: one('SELECT COUNT(*) c FROM guests').c,
    checkinsToday: one("SELECT COUNT(*) c FROM bookings WHERE check_in=? AND status IN ('booked','checked_in')", t).c,
    checkoutsToday: one("SELECT COUNT(*) c FROM bookings WHERE check_out=? AND status='checked_in'", t).c,
    revenue: one("SELECT COALESCE(SUM(total),0) s FROM bookings WHERE status IN ('checked_in','checked_out')").s,
    recent: all(`${BOOKING_SELECT} ORDER BY b.id DESC LIMIT 5`),
  });
});

// ---------- Rooms ----------
const ROOM_STATUS = ['available', 'occupied', 'maintenance'];

app.get('/api/rooms', (req, res) => {
  res.json(all('SELECT * FROM rooms ORDER BY number'));
});

app.post('/api/rooms', (req, res) => {
  const { number, type, price, capacity } = req.body || {};
  if (!number || !type || !(Number(price) > 0)) return bad(res, 'Room number, type and a valid price are required');
  if (one('SELECT id FROM rooms WHERE number=?', String(number))) return bad(res, 'Room number already exists');
  const info = db
    .prepare('INSERT INTO rooms (number, type, price, capacity) VALUES (?, ?, ?, ?)')
    .run(String(number), type, Number(price), Number(capacity) || 2);
  res.status(201).json(one('SELECT * FROM rooms WHERE id=?', info.lastInsertRowid));
});

app.put('/api/rooms/:id', (req, res) => {
  const room = one('SELECT * FROM rooms WHERE id=?', req.params.id);
  if (!room) return bad(res, 'Room not found', 404);
  const { number, type, price, capacity, status } = { ...room, ...req.body };
  if (!ROOM_STATUS.includes(status)) return bad(res, 'Invalid status');
  if (!(Number(price) > 0)) return bad(res, 'Invalid price');
  const dup = one('SELECT id FROM rooms WHERE number=? AND id<>?', String(number), room.id);
  if (dup) return bad(res, 'Room number already exists');
  db.prepare('UPDATE rooms SET number=?, type=?, price=?, capacity=?, status=? WHERE id=?').run(
    String(number), type, Number(price), Number(capacity) || 2, status, room.id
  );
  res.json(one('SELECT * FROM rooms WHERE id=?', room.id));
});

app.delete('/api/rooms/:id', (req, res) => {
  const used = one('SELECT id FROM bookings WHERE room_id=? LIMIT 1', req.params.id);
  if (used) return bad(res, 'This room has bookings, so it cannot be deleted. Set it to maintenance instead.');
  db.prepare('DELETE FROM rooms WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

// ---------- Guests ----------
app.get('/api/guests', (req, res) => {
  const q = `%${(req.query.q || '').trim()}%`;
  res.json(
    all(
      `SELECT g.*, (SELECT COUNT(*) FROM bookings b WHERE b.guest_id=g.id) AS stays
       FROM guests g
       WHERE g.name LIKE ? OR g.phone LIKE ? OR g.email LIKE ?
       ORDER BY g.id DESC`,
      q, q, q
    )
  );
});

app.post('/api/guests', (req, res) => {
  const { name, phone, email, id_proof } = req.body || {};
  if (!name || !String(name).trim()) return bad(res, 'Guest name is required');
  const info = db
    .prepare('INSERT INTO guests (name, phone, email, id_proof) VALUES (?, ?, ?, ?)')
    .run(String(name).trim(), phone || '', email || '', id_proof || '');
  res.status(201).json(one('SELECT * FROM guests WHERE id=?', info.lastInsertRowid));
});

app.put('/api/guests/:id', (req, res) => {
  const g = one('SELECT * FROM guests WHERE id=?', req.params.id);
  if (!g) return bad(res, 'Guest not found', 404);
  const { name, phone, email, id_proof } = { ...g, ...req.body };
  if (!name || !String(name).trim()) return bad(res, 'Guest name is required');
  db.prepare('UPDATE guests SET name=?, phone=?, email=?, id_proof=? WHERE id=?').run(
    String(name).trim(), phone || '', email || '', id_proof || '', g.id
  );
  res.json(one('SELECT * FROM guests WHERE id=?', g.id));
});

app.delete('/api/guests/:id', (req, res) => {
  const used = one('SELECT id FROM bookings WHERE guest_id=? LIMIT 1', req.params.id);
  if (used) return bad(res, 'This guest has booking history, so it cannot be deleted.');
  db.prepare('DELETE FROM guests WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

// ---------- Bookings ----------
app.get('/api/bookings', (req, res) => {
  const { status } = req.query;
  if (status) return res.json(all(`${BOOKING_SELECT} WHERE b.status=? ORDER BY b.id DESC`, status));
  res.json(all(`${BOOKING_SELECT} ORDER BY b.id DESC`));
});

app.post('/api/bookings', (req, res) => {
  const { guest_id, room_id, check_in, check_out, guests_count } = req.body || {};
  const guest = one('SELECT * FROM guests WHERE id=?', guest_id);
  const room = one('SELECT * FROM rooms WHERE id=?', room_id);
  if (!guest) return bad(res, 'Please select a guest');
  if (!room) return bad(res, 'Please select a room');
  if (!check_in || !check_out) return bad(res, 'Check-in and check-out dates are required');
  const nights = nightsBetween(check_in, check_out);
  if (!(nights >= 1)) return bad(res, 'Check-out must be after check-in');
  if (check_in < today()) return bad(res, 'Check-in date cannot be in the past');
  if (room.status === 'maintenance') return bad(res, `Room ${room.number} is under maintenance`);
  const count = Number(guests_count) || 1;
  if (count > room.capacity) return bad(res, `Room ${room.number} allows maximum ${room.capacity} guests`);

  const clash = one(
    `SELECT id FROM bookings
     WHERE room_id=? AND status IN ('booked','checked_in') AND check_in < ? AND check_out > ?`,
    room.id, check_out, check_in
  );
  if (clash) return bad(res, `Room ${room.number} is already booked for those dates`);

  const info = db
    .prepare('INSERT INTO bookings (guest_id, room_id, check_in, check_out, guests_count, total) VALUES (?, ?, ?, ?, ?, ?)')
    .run(guest.id, room.id, check_in, check_out, count, nights * room.price);
  res.status(201).json(one(`${BOOKING_SELECT} WHERE b.id=?`, info.lastInsertRowid));
});

// action: checkin | checkout | cancel
app.put('/api/bookings/:id/:action', (req, res) => {
  const b = one('SELECT * FROM bookings WHERE id=?', req.params.id);
  if (!b) return bad(res, 'Booking not found', 404);
  const { action } = req.params;

  const tx = db.transaction(() => {
    if (action === 'checkin') {
      if (b.status !== 'booked') throw new Error('Only a confirmed booking can be checked in');
      const room = one('SELECT status FROM rooms WHERE id=?', b.room_id);
      if (room.status !== 'available') throw new Error('Room is not available right now');
      db.prepare("UPDATE bookings SET status='checked_in' WHERE id=?").run(b.id);
      db.prepare("UPDATE rooms SET status='occupied' WHERE id=?").run(b.room_id);
    } else if (action === 'checkout') {
      if (b.status !== 'checked_in') throw new Error('Only a checked-in booking can be checked out');
      db.prepare("UPDATE bookings SET status='checked_out' WHERE id=?").run(b.id);
      db.prepare("UPDATE rooms SET status='available' WHERE id=?").run(b.room_id);
    } else if (action === 'cancel') {
      if (b.status !== 'booked') throw new Error('Only a confirmed booking can be cancelled');
      db.prepare("UPDATE bookings SET status='cancelled' WHERE id=?").run(b.id);
    } else {
      throw new Error('Unknown action');
    }
  });

  try {
    tx();
    res.json(one(`${BOOKING_SELECT} WHERE b.id=?`, b.id));
  } catch (e) {
    bad(res, e.message);
  }
});

app.listen(PORT, () => {
  console.log(`Hotel Management System running at http://localhost:${PORT}`);
  console.log(`Login -> username: ${ADMIN_USER} | password: ${ADMIN_PASS}`);
});
