# StayEase - Hotel Management System

Simple full-stack project: **Node.js + Express + SQLite** backend, **HTML/CSS/vanilla JS** frontend.

## Features
- Admin login (token based)
- Dashboard: rooms stats, today's check-ins/check-outs, guests, revenue, recent bookings
- Rooms: add / edit / delete, filter by status (available, occupied, maintenance)
- Guests: add / edit / delete, search by name, phone, email
- Bookings: create with auto total price, date-clash check, capacity check, check-in / check-out / cancel
- Responsive modern UI

## Run
```bash
npm install
npm start
```
Open http://localhost:3000

Login: `admin` / `admin123` (change in `server.js`)

The SQLite database (`hotel.db`) is created automatically with demo data on first run.

## Structure
```
hotel-management/
  server.js        # Express API (auth, dashboard, rooms, guests, bookings)
  db.js            # SQLite schema + seed data
  package.json
  public/
    index.html     # UI shell
    style.css      # styling
    app.js         # frontend logic (views, forms, API calls)
```

## API
| Method | Endpoint | Purpose |
|---|---|---|
| POST | /api/login | login, returns token |
| GET | /api/dashboard | stats |
| GET/POST | /api/rooms | list / add room |
| PUT/DELETE | /api/rooms/:id | edit / delete room |
| GET/POST | /api/guests | list (?q=search) / add guest |
| PUT/DELETE | /api/guests/:id | edit / delete guest |
| GET/POST | /api/bookings | list (?status=) / create booking |
| PUT | /api/bookings/:id/checkin \| checkout \| cancel | booking actions |

All `/api` routes except login need header `Authorization: Bearer <token>`.

## Deploy on Render (free public link)
1. Push this folder to a GitHub repo.
2. Render.com -> New -> Web Service -> select the repo.
3. Build Command: `npm install`  |  Start Command: `npm start`
4. After deploy you get `https://<name>.onrender.com` (works on mobile).

Note: on the free plan the SQLite file can reset when the service restarts.
